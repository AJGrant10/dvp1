###### DVP1 - Coding
---

# About Challenges
Each week you are required to work on code using C#. 

This folder contains some of that material. Refer to your recurring Progress Check assignments for additional information. 

Attend or view all GoTo / Lectures to understand what code is required for each milestone. 


