# Welcome to Project & Portfolio!

This repository will be used to keep track of _Project & Portfolio 1_ research and development conducted during class. Follow the instructions below to get started.

## Step 1

Review [about > README.md](./about/README.md) 


## Step 2

Begin required research for the first milestone "Version Control" (see FSO). 


## Step 3

Attend first Lecture or GoTo meeting. 

After completing the steps above, you can begin to customize this document. 






